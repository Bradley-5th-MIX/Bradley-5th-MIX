#!/bin/bash
#
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. AT YOUR OWN RISK.
#
##################################################################################################################


gsettings set org.gnome.gnome-screenshot default-file-type png 


echo "You can make screenshots in png now."
